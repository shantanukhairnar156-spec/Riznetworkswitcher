package com.rizzu.networkswitcher

enum class NetworkMode(val label: String, val bitmask: String) {
    NR_ONLY("NR ONLY", "10000000000000000000"),
    LTE_ONLY("LTE ONLY", "01000001000000000000");

    fun next() = if (this == NR_ONLY) LTE_ONLY else NR_ONLY
}
