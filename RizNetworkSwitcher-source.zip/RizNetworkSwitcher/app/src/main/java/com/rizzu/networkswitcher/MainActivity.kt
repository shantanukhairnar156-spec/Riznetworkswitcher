package com.rizzu.networkswitcher

import android.app.Activity
import android.os.Bundle
import android.widget.*
import android.content.Intent
import android.provider.Settings
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.graphics.Color

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var sim: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(Color.rgb(17, 22, 25))
        }
        fun text(value: String, size: Float, color: Int = Color.WHITE) =
            TextView(this).apply { text = value; textSize = size; setTextColor(color) }
        root.addView(text("RIZ NETWORK", 13f, Color.rgb(154, 190, 170)))
        root.addView(text("Switcher", 30f).apply { setTypeface(null, Typeface.BOLD) })
        status = text("Checking Shizuku…", 14f, Color.LTGRAY)
        root.addView(status, margin(0, 18, 0, 18))
        sim = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("SIM 1 (slot 0)", "SIM 2 (slot 1)"))
            setSelection(getSharedPreferences("network_tile", MODE_PRIVATE).getInt("slot", 0))
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                    getSharedPreferences("network_tile", MODE_PRIVATE).edit().putInt("slot", position).apply()
                }
            }
        }
        root.addView(sim, margin(0, 0, 0, 16))
        val nr = button("Switch to NR ONLY  ·  5G")
        val lte = button("Switch to LTE ONLY  ·  4G")
        root.addView(nr, margin(0, 8, 0, 8))
        root.addView(lte, margin(0, 8, 0, 8))
        val grant = button("Authorize with Shizuku")
        root.addView(grant, margin(0, 18, 0, 8))
        grant.setOnClickListener { ShizukuRunner.requestPermission(); refreshStatus() }
        nr.setOnClickListener { apply(NetworkMode.NR_ONLY) }
        lte.setOnClickListener { apply(NetworkMode.LTE_ONLY) }
        root.addView(text("Add tile: pull down Quick Settings → Edit tiles → drag “Riz Network” into the active area.", 13f, Color.LTGRAY), margin(0, 22, 0, 8))
        root.addView(button("Open wireless debugging settings").apply {
            setOnClickListener { startActivity(Intent(Settings.ACTION_WIRELESS_DEBUGGING_SETTINGS)) }
        }, margin(0, 8, 0, 8))
        setContentView(root)
        refreshStatus()
    }

    private fun margin(l: Int, t: Int, r: Int, b: Int) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { setMargins(l, t, r, b) }

    private fun button(label: String) = Button(this).apply { text = label; isAllCaps = false }

    private fun refreshStatus() {
        status.text = when {
            !ShizukuRunner.available() -> "Shizuku: not running"
            !ShizukuRunner.permissionGranted() -> "Shizuku: running · authorization needed"
            else -> "Shizuku: connected · shell permission granted"
        }
    }

    private fun apply(mode: NetworkMode) {
        val slot = sim.selectedItemPosition
        Thread {
            val result = ShizukuRunner.setMode(slot, mode)
            runOnUiThread {
                Toast.makeText(this, result.getOrElse { it.message ?: "Failed" }, Toast.LENGTH_LONG).show()
                refreshStatus()
            }
        }.start()
    }

    override fun onResume() { super.onResume(); if (::status.isInitialized) refreshStatus() }
}
