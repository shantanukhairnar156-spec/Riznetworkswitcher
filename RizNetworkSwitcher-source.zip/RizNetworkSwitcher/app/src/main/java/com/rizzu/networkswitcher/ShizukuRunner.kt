package com.rizzu.networkswitcher

import android.content.Context
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

object ShizukuRunner {
    const val REQUEST_CODE = 4317

    fun available(): Boolean = Shizuku.pingBinder()

    fun permissionGranted(): Boolean =
        available() && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED

    fun requestPermission() {
        if (available() && !permissionGranted()) Shizuku.requestPermission(REQUEST_CODE)
    }

    /**
     * Runs the AOSP telephony shell command as Shizuku's shell UID.
     * Device/OEM builds may reject it. Success is accepted only if readback matches.
     */
    fun setMode(slotId: Int, mode: NetworkMode): Result<String> = runCatching {
        check(available()) { "Shizuku is not running. Start Shizuku first." }
        check(permissionGranted()) { "Riz Network Switcher has not been authorized in Shizuku." }
        require(slotId in 0..1) { "SIM slot must be 0 or 1." }

        val command = "cmd phone set-allowed-network-types-for-users -s $slotId ${mode.bitmask}"
        val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
        val stdout = BufferedReader(InputStreamReader(process.inputStream)).readText()
        val stderr = BufferedReader(InputStreamReader(process.errorStream)).readText()
        val exit = process.waitFor()
        check(exit == 0) { "Telephony command rejected (exit $exit): ${stderr.ifBlank { stdout }}" }

        val verify = Shizuku.newProcess(
            arrayOf("sh", "-c", "cmd phone get-allowed-network-types-for-users -s $slotId"),
            null, null
        )
        val readback = BufferedReader(InputStreamReader(verify.inputStream)).readText().trim()
        val verifyErr = BufferedReader(InputStreamReader(verify.errorStream)).readText()
        val verifyExit = verify.waitFor()
        check(verifyExit == 0) { "Could not verify modem setting: $verifyErr" }
        check(readback.contains(mode.bitmask)) {
            "Command ran but readback did not match. Returned: $readback"
        }
        "Verified SIM ${slotId + 1}: ${mode.label} ($readback)"
    }
}
