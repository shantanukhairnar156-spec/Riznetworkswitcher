package com.rizzu.networkswitcher

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.content.SharedPreferences
import android.widget.Toast
import android.os.Handler
import android.os.Looper

class NetworkTileService : TileService() {
    private val prefs: SharedPreferences by lazy { getSharedPreferences("network_tile", MODE_PRIVATE) }

    override fun onStartListening() {
        super.onStartListening()
        updateTile()
    }

    override fun onClick() {
        super.onClick()
        val current = prefs.getString("mode", NetworkMode.LTE_ONLY.name)
        val target = if (current == NetworkMode.NR_ONLY.name) NetworkMode.LTE_ONLY else NetworkMode.NR_ONLY
        val slot = prefs.getInt("slot", 0)
        Thread {
            val result = ShizukuRunner.setMode(slot, target)
            if (result.isSuccess) prefs.edit().putString("mode", target.name).apply()
            val message = result.fold({ it }, { it.message ?: "Network switch failed" })
            Handler(Looper.getMainLooper()).post {
                Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                updateTile()
            }
        }.start()
    }

    private fun updateTile() {
        val mode = prefs.getString("mode", NetworkMode.LTE_ONLY.name)
        qsTile?.apply {
            label = if (mode == NetworkMode.NR_ONLY.name) "NR ONLY" else "LTE ONLY"
            subtitle = "Riz Network"
            state = if (mode == NetworkMode.NR_ONLY.name) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            updateTile()
        }
    }
}
