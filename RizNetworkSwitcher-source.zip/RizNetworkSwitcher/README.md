# Riz Network Switcher (prototype)

Native Kotlin Android app with a Quick Settings tile and Shizuku shell integration.

## Important compatibility note

The app sends AOSP's `cmd phone set-allowed-network-types-for-users` command through Shizuku's shell UID and verifies the result with the matching `get-allowed-network-types-for-users` command. This is **not guaranteed** on OPPO ColorOS. Shizuku started through Wireless Debugging normally runs as Android shell (UID 2000), not root. OEM builds may deny the telephony shell command. The tile reports failure rather than pretending the modem changed.

AOSP documents the command and bitmasks:
- NR only: `10000000000000000000`
- LTE only: `01000001000000000000`

NR-only means 5G NR only and can drop service where NR SA is unavailable. It is not a general 5G Auto mode.

## Build

Open this folder in Android Studio (JDK 17, Android SDK 36), allow Gradle sync, then Build > Build APK(s).

## Install and setup

1. Install Shizuku from its official source and start it using Wireless debugging.
2. Install Riz Network Switcher.
3. Open it and tap **Authorize with Shizuku**.
4. Pull down Quick Settings twice, tap Edit, and add **Riz Network**.
5. Select SIM 1 or SIM 2 in the app. Current prototype uses SIM slot index 0 or 1.
6. Tap the tile. It verifies the shell command readback before showing success.

## Security

No root, no API key, no Gemini API call and no internet access are required for the switching operation. Do not share Wireless Debugging pairing codes or Shizuku authorization with untrusted apps.

## Known prototype limitations

- Tested build not produced here; requires Android Studio/Gradle build.
- AOSP shell command may be unavailable or permission-blocked on OPPO firmware.
- Tile stores the last verified mode; it does not yet independently query live modem state when the panel opens.
- LTE-only bitmask follows AOSP command help and should be tested on the target firmware.
